/**
 * The utillib library.
 * More information is available at http://www.jinchess.com/.
 * Copyright (C) 2002 Alexander Maryanovsky.
 * All rights reserved.
 *
 * The utillib library is free software; you can redistribute
 * it and/or modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * The utillib library is distributed in the hope that it will
 * be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with utillib library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package free.util;

/**
 * A runnable which catches and prints all Throwables except ThreadDeath 
 * thrown within its run method. This should be used by code invoking some user
 * code to prevent the calling thread from dying because some exception was thrown
 * in the user code.
 */

public abstract class SafeRunnable implements Runnable{


  /**
   * Wraps a call to safeRun() within a try..catch block which catches and
   * prints all RuntimeExceptions and Errors (except ThreadDeath) to the standard
   * error stream.
   */

  public void run(){
    try{
      safeRun();
    } catch (Throwable t){
        if (t instanceof ThreadDeath)
          throw (ThreadDeath)t;

        System.err.println("An exception/error occurred while handling data:");
        t.printStackTrace();
      }
  }



  /**
   * The method that should be implemented instead of the run() method.
   */

  public abstract void safeRun();

}
