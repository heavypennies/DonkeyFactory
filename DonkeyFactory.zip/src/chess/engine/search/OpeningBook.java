package chess.engine.search;

/**
 * OpeningBook
 *
 * @author jlevine
 */
public class OpeningBook extends PositionHashtable
{
/*
  public HashEntry getEntry(Board board)
  {
    return super.getEntry(board);
  }

  public void putEntry(int depth, int type, int score, Board board, Move move, boolean mateThreat)
  {
    super.putEntry(depth, type, score, board, move, mateThreat);
  }
*/
}
