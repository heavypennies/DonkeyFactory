/* $Id$ */

package chess.engine.search;

import chess.engine.model.Board;
import chess.engine.model.Piece;
import chess.engine.model.Square;
import chess.engine.utils.MoveGeneration;

/**
 * @author Joshua Levine <jlevine@theladders.com>
 * @version $Revision$ $Name$ $Date$
 */
public class SimpleEvaluator implements BoardEvaluator
{
  private static boolean DEBUG = false;

  // ...
  private static int CENTER_CHECK_BALANCE = 12;

  // Material Values
  private static double MATERIAL_DIVISOR = 31D;
  private static int TRADE_WHEN_LOSING_VALUE = 10;
  private static int TRADE_WHEN_UP_PAWNS_VALUE = 30;

  // Opening values
  private static int DEVELOPMENT_VALUE = 3;
  private static int PIECE_DOUBLE_MOVE_VALUE = 2;
  private static int QUEEN_TOO_EARLY_VALUE = 23;

  // Pawn values
  private static int[] WHITE_PASSED_PAWN_VALUES = new int[]{0, 7, 14, 30, 90, 150, 250, 250};
  private static int[] BLACK_PASSED_PAWN_VALUES = new int[]{250, 250, 150, 90, 30, 14, 7, 0};

  private static int PAWN_DOUBLED_VALUE = 32;
  private static int[] PAWN_BACKWARDS_VALUE = new int[]{18, 21, 24, 27, 27, 24, 21, 18};
  private static int UNMOVED_CENTER_PAWN = 0;
  private static int UNMOVED_CENTER_PAWN_BLOCKED = 35;
  private static int UNMOVED_CENTER_PAWN_ALMOST_BLOCKED = 8;
  private static int PAWN_LOCKED_VALUE = 9;
  private static int PASSED_PAWN_WIDE_FILE_VALUE = 15;

  private static int PAWN_PHALANX_VALUE = 4;
  private static int[] PAWN_CHAIN_VALUE = {2, 3, 4, 6, 6, 4, 3, 2};

  // Knight Values
  private static int KNIGHT_TRAPPED_VALUE = 50;
  private static int KNIGHT_OUTPOST_VALUE = 18;

  // Bishop Values
  private static int TWO_BISHOPS_VALUE = 19;
  private static int BISHOP_TRAPPED_VALUE = 7;
  private static int BISHOP_OPEN_DIAGONAL_VALUE = 9;

  // Rook Values
  private static int ROOK_ON_OPEN_FILE = 18;
  private static int ROOK_ON_HALF_OPEN_FILE = 12;
  private static int TRAPPED_ROOK_VALUE = 240;
  private static int ROOK_OPPOSITE_KING_VALUE = 4;
  private static int ROOK_OPPOSITE_KING_HALF_OPEN_VALUE = 12;
  private static int ROOK_OPPOSITE_KING_OPEN_VALUE = 100;

  // King Values
  private static int KING_NO_CASTLE_VALUE = 8;
  private static int KING_FORFEIT_CASTLE_VALUE = 22;
  private static int KING_ON_OPEN_FILE = 91;
  private static int KING_ON_HALF_OPEN_FILE = 49;
  private static int WAITING_TO_CASTLE_VALUE = 8;
  private static int KING_OPEN_FILE = 23;
  private static int KING_HALF_OPEN_FILE = 16;
  private static int CASTLE_DESTINATION_VALUE = 12;

  private static int CHECK_IMMEDIATE_KING_VALUE = 3;
  private static int CHECK_NEARBY_KING_VALUE = 3;

  // Piece masks
  private static int PAWN_MASK = 8;
  private static int ROOK_MASK = 16;
  private static int MINOR_MASK = 32;
  private static int QUEEN_MASK = 64;
  private static int KING_MASK = 128;

  private MoveGeneration moveGeneration;

  public PawnHashtable pawnHash = new PawnHashtable();

  public SimpleEvaluator(MoveGeneration moveGeneration)
  {
    this.moveGeneration = moveGeneration;
    for (int square = 0; square < 64; square++)
    {

      SMALL_KING_AREA[square] = getSmallKingArea(Board.SQUARES[square]);
      KING_AREA_A1_H8[square] = getKingAreaA1H8(Board.SQUARES[square]);
      KING_AREA_H1_A8[square] = getKingAreaH1A8(Board.SQUARES[square]);
    }
    // ABC vs ABC
    // ABC vs AB
    // ABC vs A C
    // ABC vs  BC
    // ABC vs A
    // ABC vs  B
    // ABC vs   C
    // ABC vs
    // etc
    for(int blackPawns = 0; blackPawns < 8; blackPawns++)
    {
      for(int whitePawns = 0; whitePawns < 8; whitePawns++)
      {
        PAWNSCORES[(whitePawns << 3) | blackPawns] = scorePawnWing(whitePawns, blackPawns);
      }
    }
  }

  int scorePawnWing(int whitePawns, int blackPawns)
  {
    return Board.countBits(whitePawns) == Board.countBits(blackPawns) ? 0 : Board.countBits(whitePawns) > Board.countBits(blackPawns) ? 25 : -25;

    //return new PawnWingScorer(moveGeneration, this).scorePawnWing(whitePawns, blackPawns);
  }

  public void reset()
  {
    //pawnHash.clear();
  }

  static long DARK_SQUARES;
  static long LIGHT_SQUARES;
  static long[] FILES = new long[8];
  static long[] RANKS = new long[8];

  static long[] WHITE_PASSED_MASK = new long[64];
  static long[] BLACK_PASSED_MASK = new long[64];

  static long[] WHITE_BACKWARDS_MASK = new long[64];
  static long[] BLACK_BACKWARDS_MASK = new long[64];

  private static long[] WHITE_KNIGHT_OUTPOST_MASK = new long[64];
  private static long[] BLACK_KNIGHT_OUTPOST_MASK = new long[64];

  static long[] SMALL_KING_AREA = new long[64];
  static long[] KING_AREA_A1_H8 = new long[64];
  static long[] KING_AREA_H1_A8 = new long[64];

  static long[] WHITE_HALF = new long[64];
  static long[] BLACK_HALF = new long[64];

  static
  {
    for (int square = 0; square < 64; square++)
    {
      if (square % 2 == 0)
      {
        DARK_SQUARES |= Board.SQUARES[square].mask_on;
      }
      else
      {
        LIGHT_SQUARES |= Board.SQUARES[square].mask_on;
      }

      FILES[Board.SQUARES[square].file] |= Board.SQUARES[square].mask_on;
      RANKS[Board.SQUARES[square].rank] |= Board.SQUARES[square].mask_on;
    }

    for (int square = 0; square < 64; square++)
    {
      // Initialize white passed pawn masks
      for (int rank = Board.SQUARES[square].rank + 1; rank < 7; rank++)
      {
        if (Board.SQUARES[square].file == 0)
        {
          WHITE_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank)].mask_on;
          WHITE_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) + 1].mask_on;
        }
        else if (Board.SQUARES[square].file == 7)
        {
          WHITE_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) - 1].mask_on;
          WHITE_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank)].mask_on;
        }
        else
        {
          WHITE_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) - 1].mask_on;
          WHITE_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank)].mask_on;
          WHITE_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) + 1].mask_on;
        }
      }

      // Initialize black passed pawn masks
      for (int rank = 0; rank < Board.SQUARES[square].rank; rank++)
      {
        if (Board.SQUARES[square].file == 0)
        {
          BLACK_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank)].mask_on;
          BLACK_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) + 1].mask_on;
        }
        else if (Board.SQUARES[square].file == 7)
        {
          BLACK_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) - 1].mask_on;
          BLACK_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank)].mask_on;
        }
        else
        {
          BLACK_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) - 1].mask_on;
          BLACK_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank)].mask_on;
          BLACK_PASSED_MASK[square] |= Board.SQUARES[Board.SQUARES[square].file + (8 * rank) + 1].mask_on;
        }
      }

      WHITE_BACKWARDS_MASK[square] = BLACK_PASSED_MASK[square];
      BLACK_BACKWARDS_MASK[square] = WHITE_PASSED_MASK[square];

      if (Board.SQUARES[square].file > 0)
      {
        WHITE_BACKWARDS_MASK[square] |= Board.SQUARES[square - 1].mask_on;
        BLACK_BACKWARDS_MASK[square] |= Board.SQUARES[square - 1].mask_on;
      }
      if (Board.SQUARES[square].file < 7)
      {
        WHITE_BACKWARDS_MASK[square] |= Board.SQUARES[square + 1].mask_on;
        BLACK_BACKWARDS_MASK[square] |= Board.SQUARES[square + 1].mask_on;
      }

      WHITE_KNIGHT_OUTPOST_MASK[square] = WHITE_PASSED_MASK[square] & ~FILES[Board.file(square)];
      BLACK_KNIGHT_OUTPOST_MASK[square] = BLACK_PASSED_MASK[square] & ~FILES[Board.file(square)];

      for (int i = 0; i <= Board.SQUARES[square].rank; i++)
      {
        WHITE_HALF[square] |= RANKS[i];
      }
      for (int i = 7; i >= Board.SQUARES[square].rank; i--)
      {
        BLACK_HALF[square] |= RANKS[i];
      }
    }

  }

  static int[] PAWNSCORES = new int[64];

  static long FILES_ABCD = FILES[0] | FILES[1] | FILES[2] | FILES[3];
  static long FILES_EFGH = FILES[4] | FILES[5] | FILES[6] | FILES[7];

  static long FILES_AB = FILES[0] | FILES[1];
  static long FILES_CD = FILES[2] | FILES[3];
  static long FILES_EF = FILES[4] | FILES[6];
  static long FILES_GH = FILES[6] | FILES[7];

  static long FILES_DE = FILES[3] | FILES[4];

  static long CENTER = (FILES_CD | FILES_EF) & (RANKS[3] | RANKS[4]);

  public static int[][][] PIECE_VALUE_TABLES = new int[2][8][64];

  static int[] CHECK_VALUE_TABLE_WHITE_O_O = new int[]{
          3, 3, 3, 5, 5, 7, 9, 9,
          2, 4, 4, 5, 5, 6, 7, 7,
          2, 2, 2, 4, 4, 5, 5, 5,
          1, 1, 2, 3, 4, 4, 4, 3,
  };
  static int[] CHECK_VALUE_TABLE_BLACK_O_O = new int[]{
          1, 1, 2, 3, 4, 4, 4, 3,
          2, 2, 2, 4, 4, 5, 5, 5,
          2, 4, 4, 5, 5, 6, 7, 7,
          3, 3, 3, 5, 5, 7, 9, 9,
  };
  static int[] CHECK_VALUE_TABLE_WHITE_O_O_O = new int[]{
          9, 9, 7, 5, 5, 3, 3, 3,
          7, 7, 6, 5, 5, 4, 4, 2,
          5, 5, 5, 4, 4, 2, 2, 2,
          3, 4, 4, 4, 3, 2, 1, 1,
  };
  static int[] CHECK_VALUE_TABLE_BLACK_O_O_O = new int[]{
          3, 4, 4, 4, 3, 2, 1, 1,
          5, 5, 5, 4, 4, 2, 2, 2,
          7, 7, 6, 5, 5, 4, 4, 2,
          9, 9, 7, 5, 5, 3, 3, 3,
  };
  static int[] CHECK_VALUE_TABLE_WHITE_CENTER = new int[]{
          5, 9, 9, 9, 9, 9, 9, 5,
          2, 2, 5, 5, 5, 5, 2, 2,
          1, 1, 3, 4, 4, 3, 1, 1,
          1, 2, 3, 4, 4, 3, 2, 1,
  };

  static int[] CHECK_VALUE_TABLE_BLACK_CENTER = new int[]{
          1, 2, 3, 4, 4, 3, 2, 1,
          1, 1, 3, 4, 4, 3, 1, 1,
          2, 2, 5, 5, 5, 5, 2, 2,
          5, 7, 9, 9, 9, 9, 7, 5,
  };

  static long mask2 = Square.A1.mask_on | Square.B1.mask_on;
  static long mask3 = Square.A1.mask_on | Square.B1.mask_on | Square.C1.mask_on;

  static long mask3x2 = Square.A1.mask_on | Square.B1.mask_on | Square.C1.mask_on |
                              Square.A2.mask_on | Square.B2.mask_on | Square.C2.mask_on;


  static
  {
    // White Pawn
    PIECE_VALUE_TABLES[1][Piece.PAWN] = new int[]{
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 5, 5, 5,
            1, 1, 4, 5, 5, 2, 1, 1,
            2, 2, 10, 14, 15,  7, 2, 2,
            5, 7, 12, 16, 17, 12, 7, 6,
            8, 12, 16, 16, 16, 14, 12, 8,
            10, 22, 32, 50, 51, 32, 22, 10,
            0, 0, 0, 0, 0, 0, 0, 0,
    };

    // Black Pawn
    PIECE_VALUE_TABLES[0][Piece.PAWN] = new int[]{
            0, 0, 0, 0, 0, 0, 0, 0,
            10, 22, 32, 50, 51, 32, 22, 10,
            8, 12, 16, 18, 19, 24, 12, 8,
            5, 7, 12, 16, 17, 12, 7, 6,
            2, 2, 10, 14, 15,  7, 2, 2,
            1, 1, 4, 5, 5, 2, 1, 1,
            0, 0, 0, 0, 0, 5, 5, 5,
            0, 0, 0, 0, 0, 0, 0, 0,
    };

    // White knight
    PIECE_VALUE_TABLES[1][Piece.KNIGHT] = new int[]{
            -10, -3, -7, -5, -5, -7, -3, -10,
            -8, 1, 3, 4, 4, 3, 1, -8,
            -4, 8, 8, 10, 10, 9, 8, -4,
            -3, 5, 12, 14, 14, 12, 5, -3,
            -3, 6, 16, 15, 15, 16, 6, -3,
            -3, 5, 10, 12, 16, 15, 5, -3,
            1, 2, 9, 9, 9, 9, 2, 1,
            -10, -8, -7, -5, -5, -7, -8, -10,
    };
    // Black knight
    PIECE_VALUE_TABLES[0][Piece.KNIGHT] = new int[]{
            -10, -8, -7, -5, -5, -7, -8, -10,
            1, 2, 9, 9, 9, 9, 2, 1,
            -3, 5, 10, 12, 16, 15, 5, -3,
            -3, 6, 13, 15, 15, 16, 6, -3,
            -3, 5, 12, 14, 14, 12, 5, -3,
            -4, 8, 8, 10, 10, 9, 8, -4,
            -8, 1, 3, 4, 4, 3, 1, -8,
            -10, -3, -7, -5, -5, -7, -3, -10,
    };

    // White bishop
    PIECE_VALUE_TABLES[1][Piece.BISHOP] = new int[]{
            -4, -3, -2, -1, -1, -2, -3, -4,
            -5, 6, 1, 7, 7, 1, 6, -5,
            0, 5, 7, 8, 8, 7, 5, 0,
            0, 1, 13, 18, 18, 13, 1, 0,
            0, 8, 15, 18, 18, 15, 8, 0,
            0, 1, 9, 10, 10, 9, 1, 0,
            0, 2, 2, 3, 3, 2, 2, 0,
            -4, -3, -2, -1, -1, -2, -3, -4,
    };
    // Black bishop
    PIECE_VALUE_TABLES[0][Piece.BISHOP] = new int[]{
            -4, -3, -2, -1, -1, -2, -3, -4,
            0, 2, 2, 3, 3, 2, 2, 0,
            0, 1, 9, 10, 10, 9, 1, 0,
            0, 8, 15, 18, 18, 15, 8, 0,
            0, 1, 13, 18, 18, 13, 1, 0,
            0, 5, 7, 8, 8, 7, 5, 0,
            -5, 6, 1, 7, 7, 1, 6, -5,
            -4, -3, -2, -1, -1, -2, -3, -4,
    };

    // White rook
    PIECE_VALUE_TABLES[1][Piece.ROOK] = new int[]{
            -4, -5, 1, 6, 6, 3, -5, -4,
            -5, 0, 1, 6, 6, 1, 0, -5,
            -3, 1, 2, 7, 7, 2, 1, -3,
            -3, 2, 3, 8, 8, 3, 2, -3,
            -3, 3, 4, 9, 9, 4, 3, -3,
            -2, 3, 5, 10, 10, 5, 3, -2,
            12, 18, 22, 25, 25, 22, 18, 12,
            6, 6, 6, 6, 6, 6, 6, 6,
    };
    // Black rook
    PIECE_VALUE_TABLES[0][Piece.ROOK] = new int[]{
            6, 6, 6, 6, 6, 6, 6, 6,
            12, 18, 22, 25, 25, 22, 18, 12,
            -2, 3, 5, 10, 10, 5, 3, -2,
            -3, 3, 4, 9, 9, 4, 3, -3,
            -3, 2, 3, 8, 8, 3, 2, -3,
            -3, 1, 2, 7, 7, 2, 1, -3,
            -5, 0, 1, 6, 6, 1, 0, -5,
            -4, -5, 1, 6, 6, 3, -5, -4,
    };
    // White Queen
    PIECE_VALUE_TABLES[1][Piece.QUEEN] = new int[]{
            -12, -12, -8, 4, 4, -8, -12, -12,
            -6, -5, 1, 5, 5, 1, -5, -6,
            0, 1, 7, 11, 11, 7, 1, 0,
            0, 1, 8, 13, 13, 8, 1, 0,
            0, 1, 5, 11, 11, 5, 1, 0,
            0, 1, 5, 10, 10, 5, 1, 0,
            7, 8, 9, 11, 11, 9, 8, 7,
            5, 6, 6, 8, 8, 6, 6, 5,
    };
    // Black Queen
    PIECE_VALUE_TABLES[0][Piece.QUEEN] = new int[]{
            5, 6, 6, 8, 8, 6, 6, 5,
            7, 8, 9, 11, 11, 9, 8, 7,
            0, 1, 5, 10, 10, 5, 1, 0,
            0, 1, 5, 11, 11, 5, 1, 0,
            0, 1, 8, 13, 13, 8, 1, 0,
            0, 1, 7, 11, 11, 7, 1, 0,
            -6, -5, 1, 5, 5, 1, -5, -6,
            -12, -12, -8, 4, 4, -8, -12, -12,
    };
    // King
    PIECE_VALUE_TABLES[0][Piece.KING] = new int[]{
            2, 1, 1, 2, 2, 1, 1, 1,
            1, 2, 2, 3, 3, 2, 3, 1,
            3, 3, 4, 4, 4, 4, 3, 3,
            3, 4, 5, 6, 6, 5, 4, 3,
            3, 4, 5, 6, 6, 5, 4, 3,
            3, 3, 4, 4, 4, 4, 3, 3,
            1, 3, 2, 3, 3, 2, 3, 1,
            2, 1, 1, 2, 2, 1, 1, 1,
    };

  }

  public static class PawnFlags
  {
    public long whitePassedPawns;
    public long blackPassedPawns;
    public long openFiles;
    public long openRanks;
    public long lockedFiles;
    public int score;
    public int whitePawnCount;
    public int blackPawnCount;
    public long[] closedFiles;
    public int endgameScore;
    public int centerScore;

    public PawnFlags()
    {
      closedFiles = new long[]{0L, 0L};
      reset();
    }

    public void reset()
    {
      whitePassedPawns = 0;
      blackPassedPawns = 0;
      openFiles = ~0L;
      openRanks = ~0L;
      lockedFiles = 0;
      score = 0;
      whitePawnCount = 0;
      blackPawnCount = 0;
      closedFiles[0] = 0;
      closedFiles[1] = 0;

      endgameScore = 0;
      centerScore = 0;
    }
  }

  public int scorePosition(Board board, int alpha, int beta)
  {
//    moveGeneration.generateChecks(board);
    //if(DEBUG)System.err.println(board.toString());

    int score = 0;

    int whiteMaterial = 0;
    int blackMaterial = 0;

    // pawn position (with hash)
    PawnFlags pawnFlags = scorePawns(board);
    // TODO copy pawnflags into local pawnflags and let pieces affect open files/diagonals

    int pieceValueScore = 0;

    // Count Undeveloped Pieces
    int undevelopedWhitePieceCount = Board.countBits((RANKS[0] & (board.pieceBoards[1][Piece.KNIGHT] | board.pieceBoards[1][Piece.BISHOP]))) + (board.stats.whiteCastleFlag == 0 ?
                                                                                                                                                1 :
                                                                                                                                                0);
    int undevelopedBlackPieceCount = Board.countBits((RANKS[7] & (board.pieceBoards[0][Piece.KNIGHT] | board.pieceBoards[0][Piece.BISHOP]))) + (board.stats.blackCastleFlag == 0 ?
                                                                                                                                                1 :
                                                                                                                                                0);

    // Eval Piece by piece
    int square;
    long pieces = board.pieceBoards[1][Piece.KNIGHT];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score += Piece.TYPE_VALUES[Piece.KNIGHT];
      pieceValueScore += PIECE_VALUE_TABLES[1][Piece.KNIGHT][square];
      whiteMaterial += 3;

      pieceValueScore -= (undevelopedWhitePieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;

      if ((WHITE_KNIGHT_OUTPOST_MASK[square] & board.pieceBoards[0][Piece.PAWN]) == 0 && Board.SQUARES[square].rank >= 3)
      {
        pieceValueScore += KNIGHT_OUTPOST_VALUE + (2 * (Board.rank(square) - 4));
      }
    }

    pieces = board.pieceBoards[0][Piece.KNIGHT];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score -= Piece.TYPE_VALUES[Piece.KNIGHT];
      pieceValueScore -= PIECE_VALUE_TABLES[0][Piece.KNIGHT][square];
      blackMaterial += 3;

      pieceValueScore += (undevelopedBlackPieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;

      if ((BLACK_KNIGHT_OUTPOST_MASK[square] & board.pieceBoards[1][Piece.PAWN]) == 0 && Board.SQUARES[square].rank <= 4)
      {
        pieceValueScore -= KNIGHT_OUTPOST_VALUE + (2 * (4-Board.rank(square)));
      }
    }

    pieces = board.pieceBoards[1][Piece.BISHOP];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score += Piece.TYPE_VALUES[Piece.BISHOP];
      pieceValueScore += PIECE_VALUE_TABLES[1][Piece.BISHOP][square];
      whiteMaterial += 3;

      if (pieces != 0)
      {
        pieceValueScore += TWO_BISHOPS_VALUE;
      }

/*
      if(((MoveGeneration.attackVectors[1][Piece.KING][square] & ~MoveGeneration.attackVectors[1][Piece.ROOK][square]) & ~board.pieceBoards[1][Board.ALL_PIECES]) == 0)
      {
        pieceValueScore -= BISHOP_TRAPPED_VALUE;
      }
*/
      pieceValueScore -= (undevelopedWhitePieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;
      pieceValueScore += board.bishopMobility(square);
    }

    pieces = board.pieceBoards[0][Piece.BISHOP];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score -= Piece.TYPE_VALUES[Piece.BISHOP];
      pieceValueScore -= PIECE_VALUE_TABLES[0][Piece.BISHOP][square];
      blackMaterial += 3;
      if (pieces != 0)
      {
        pieceValueScore -= TWO_BISHOPS_VALUE;
      }

/*
      if(((MoveGeneration.attackVectors[0][Piece.KING][square] & ~MoveGeneration.attackVectors[0][Piece.ROOK][square]) & ~board.pieceBoards[0][Board.ALL_PIECES]) == 0)
      {
        pieceValueScore += BISHOP_TRAPPED_VALUE;
      }
*/
      pieceValueScore += (undevelopedBlackPieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;
      pieceValueScore -= board.bishopMobility(square);
    }

    pieces = board.pieceBoards[1][Piece.ROOK];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score += Piece.TYPE_VALUES[Piece.ROOK];
      pieceValueScore += PIECE_VALUE_TABLES[1][Piece.ROOK][square];
      whiteMaterial += 5;

/*
      if (square == Square.A1.index64 && board.whiteKing.square.index64 == Square.B1.index64)
      {
        pieceValueScore -= TRAPPED_ROOK_VALUE;
      }
      if (square == Square.H1.index64 && board.blackKing.square.index64 == Square.G1.index64)
      {
        pieceValueScore -= TRAPPED_ROOK_VALUE;
      }
*/
      if (((Board.SQUARES[square].mask_on & pawnFlags.openFiles) != 0))
      {
        pieceValueScore += ROOK_ON_OPEN_FILE;
      }
      else if (((Board.SQUARES[square].mask_on & pawnFlags.closedFiles[1]) == 0))
      {
        pieceValueScore += ROOK_ON_HALF_OPEN_FILE;
      }
/*
      else if (((Board.SQUARES[square].mask_on & pawnFlags.lockedFiles) != 0))
      {
        pieceValueScore -= ROOK_ON_OPEN_FILE;
      }
*/
      pieceValueScore -= (undevelopedWhitePieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;
      pieceValueScore += board.rookMobility(square);
    }

    pieces = board.pieceBoards[0][Piece.ROOK];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score -= Piece.TYPE_VALUES[Piece.ROOK];
      pieceValueScore -= PIECE_VALUE_TABLES[0][Piece.ROOK][square];
      blackMaterial += 5;

/*
      if (square == Square.A8.index64 && board.blackKing.square.index64 == Square.B8.index64)
      {
        pieceValueScore += TRAPPED_ROOK_VALUE;
      }
      if (square == Square.H8.index64 && board.blackKing.square.index64 == Square.G8.index64)
      {
        pieceValueScore += TRAPPED_ROOK_VALUE;
      }
*/
      if (((Board.SQUARES[square].mask_on & pawnFlags.openFiles) != 0))
      {
        pieceValueScore -= ROOK_ON_OPEN_FILE;
      }
      else if (((Board.SQUARES[square].mask_on & pawnFlags.closedFiles[0]) == 0))
      {
        pieceValueScore -= ROOK_ON_HALF_OPEN_FILE;
      }
/*
      else if (((Board.SQUARES[square].mask_on & pawnFlags.lockedFiles) != 0))
      {
        pieceValueScore += ROOK_ON_OPEN_FILE;
      }
*/
      pieceValueScore += (undevelopedBlackPieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;
      pieceValueScore -= board.rookMobility(square);
    }

    pieces = board.pieceBoards[1][Piece.QUEEN];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score += Piece.TYPE_VALUES[Piece.QUEEN];
      pieceValueScore += PIECE_VALUE_TABLES[1][Piece.QUEEN][square];
      whiteMaterial += 9;
      pieceValueScore += board.rookMobility(square);
      pieceValueScore += board.bishopMobility(square);
      pieceValueScore -= (undevelopedWhitePieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;
    }

    pieces = board.pieceBoards[0][Piece.QUEEN];
    while (pieces != 0)
    {
      square = Board.getLeastSignificantBit(pieces);
      pieces &= Board.SQUARES[square].mask_off;
      score -= Piece.TYPE_VALUES[Piece.QUEEN];
      pieceValueScore -= PIECE_VALUE_TABLES[0][Piece.QUEEN][square];
      blackMaterial += 9;
      pieceValueScore -= board.rookMobility(square);
      pieceValueScore -= board.bishopMobility(square);
      pieceValueScore += (undevelopedBlackPieceCount == 0 ? 2 : board.boardSquares[Board.SQUARES[square].index128].piece.moveCount) * board.boardSquares[Board.SQUARES[square].index128].piece.moveCount;
    }

    score += pieceValueScore;

    if (whiteMaterial < 5 && blackMaterial < 5 && pawnFlags.whitePawnCount == 0 && pawnFlags.blackPawnCount == 0)
    {
      return 0;
    }


    if(undevelopedBlackPieceCount + undevelopedWhitePieceCount > 0)
    {
      // Develop pieces
      score += (undevelopedBlackPieceCount - undevelopedWhitePieceCount) * DEVELOPMENT_VALUE;

      // Dont move the queen too much too early
      if (undevelopedWhitePieceCount > 0 && board.pieceBoards[1][Piece.QUEEN] != 0 && board.stats.whitePieceMoves[Piece.QUEEN] > 1)
      {
        score -= min(44, board.stats.whitePieceMoves[Piece.QUEEN] * QUEEN_TOO_EARLY_VALUE);
      }
      if (undevelopedBlackPieceCount > 0 && board.pieceBoards[0][Piece.QUEEN] != 0 && board.stats.blackPieceMoves[Piece.QUEEN] > 1)
      {
        score += min(44, board.stats.blackPieceMoves[Piece.QUEEN] * QUEEN_TOO_EARLY_VALUE);
      }

      if ((board.pieceBoards[1][Piece.PAWN] & Square.E2.mask_on) != 0)
      {
        score -= UNMOVED_CENTER_PAWN;
        if ((board.pieceBoards[1][Board.ALL_PIECES] & Square.E3.mask_on) != 0)
        {
          score -= UNMOVED_CENTER_PAWN_BLOCKED;
        }
      }
      if ((board.pieceBoards[1][Piece.PAWN] & Square.D2.mask_on) != 0)
      {
        score -= UNMOVED_CENTER_PAWN;
        if ((board.pieceBoards[1][Board.ALL_PIECES] & Square.D3.mask_on) != 0)
        {
          score -= UNMOVED_CENTER_PAWN_BLOCKED;
        }
      }
      if ((board.pieceBoards[0][Piece.PAWN] & Square.E7.mask_on) != 0)
      {
        score += UNMOVED_CENTER_PAWN;
        if ((board.pieceBoards[0][Board.ALL_PIECES] & Square.E6.mask_on) != 0)
        {
          score += UNMOVED_CENTER_PAWN_BLOCKED;
        }
      }
      if ((board.pieceBoards[0][Piece.PAWN] & Square.D7.mask_on) != 0)
      {
        score += UNMOVED_CENTER_PAWN;
        if ((board.pieceBoards[0][Board.ALL_PIECES] & Square.D6.mask_on) != 0)
        {
          score += UNMOVED_CENTER_PAWN_BLOCKED;
        }
      }
    }

    double whiteMaterialRatio = 1 - (whiteMaterial / 31D);
    double blackMaterialRatio = 1 - (blackMaterial / 31D);

    score += pawnFlags.centerScore > 0 ? pawnFlags.centerScore * (1 - whiteMaterialRatio) : pawnFlags.centerScore * (1 - blackMaterialRatio);
    if(whiteMaterial > 15)
    {
      score += pawnFlags.endgameScore > 0 ? pawnFlags.endgameScore * blackMaterialRatio : pawnFlags.endgameScore * whiteMaterialRatio;
    }

    // Don't trade when down material
    if (board.stats.originalMaterialDifference < 0 && blackMaterial > whiteMaterial)
    {
      if (whiteMaterial + blackMaterial < board.stats.originalMaterial)
      {
        score -= TRADE_WHEN_LOSING_VALUE;
      }
    }
    else if (board.stats.originalMaterialDifference > 0 && whiteMaterial > blackMaterial)
    {
      if (whiteMaterial + blackMaterial < board.stats.originalMaterial)
      {
        score += TRADE_WHEN_LOSING_VALUE;
      }
    }

    // Pawns
    int pawnScore = pawnFlags.score;
    score += pawnScore;

    //if(DEBUG)System.err.println("Material Ratio: w: " + whiteMaterialRatio + " b: " + blackMaterialRatio);
    //if(DEBUG)System.err.println("Pawns: " + pawnScore);

    // Passed Pawns
    if ((pawnFlags.whitePassedPawns | pawnFlags.blackPassedPawns) != 0)
    {
      int passedPawnScore = scorePassedPawns(board,
                                             pawnFlags.whitePassedPawns,
                                             pawnFlags.blackPassedPawns,
                                             whiteMaterial,
                                             blackMaterial);
      score += passedPawnScore;
      //if(DEBUG)System.err.println("Passed Pawns: " + passedPawnScore);
    }

    // King Evals
    int whiteKingScore = evalWhiteKing(board, pawnFlags);
    int blackKingScore = evalBlackKing(board, pawnFlags);

    score += whiteKingScore;
    score -= blackKingScore;

    //if(DEBUG)System.err.println("Pieces: " + pieceValueScore);
    //if(DEBUG)System.err.println("White King: " + whiteKingScore);
    //if(DEBUG)System.err.println("Black King: " + blackKingScore);
    //if(DEBUG)System.err.println("Score: " + score);

/*
    evalWhiteKing(board, pawnFlags);
    evalBlackKing(board, pawnFlags);
*/

    return board.turn == 1 ?
           score :
           -score;
  }


  //////////////
  //   PAWNS
  //////////////
  private PawnFlags scorePawns(Board board)
  {
    // probe pawn hash
    PawnHashtable.HashEntry pawnHashEntry = pawnHash.getEntryNoNull(board);

    // if the entry is good
    if (pawnHashEntry.hash == board.pawnHash)
    {
      // return the score from the entry
      return pawnHashEntry.pawnFlags;
    }

    int score = 0;

    pawnHashEntry.pawnFlags.whitePawnCount = 0;
    pawnHashEntry.pawnFlags.blackPawnCount = 0;

    pawnHashEntry.pawnFlags.whitePassedPawns = 0;
    pawnHashEntry.pawnFlags.blackPassedPawns = 0;
    pawnHashEntry.pawnFlags.openFiles = ~0;
    pawnHashEntry.pawnFlags.openRanks = ~0;
    pawnHashEntry.pawnFlags.lockedFiles = 0;
    pawnHashEntry.pawnFlags.closedFiles[0] = 0;
    pawnHashEntry.pawnFlags.closedFiles[1] = 0;
    pawnHashEntry.pawnFlags.endgameScore = 0;

    long whitePawns = board.pieceBoards[1][Piece.PAWN];
    long blackPawns = board.pieceBoards[0][Piece.PAWN];

    int whitePawnScore = 0;
    int blackPawnScore = 0;

    int[] whitePawnValueTable = PIECE_VALUE_TABLES[1][Piece.PAWN];
    Square pawnSquare;
    while (whitePawns != 0)
    {
      int pawnSquareIndex = Board.getLeastSignificantBit(whitePawns);
      whitePawns &= (whitePawns - 1);
      pawnSquare = Board.SQUARES[pawnSquareIndex];

      //if(DEBUG)System.err.println("  P@" + pawnSquare.toString());
      whitePawnScore += Piece.TYPE_VALUES[Piece.PAWN];
      pawnHashEntry.pawnFlags.whitePawnCount++;
      pawnHashEntry.pawnFlags.openFiles &= ~FILES[pawnSquare.file];
      pawnHashEntry.pawnFlags.openRanks &= ~RANKS[pawnSquare.rank];
      whitePawnScore += whitePawnValueTable[pawnSquareIndex];
      pawnHashEntry.pawnFlags.closedFiles[1] |= FILES[pawnSquare.file] & WHITE_HALF[pawnSquare.index64];

      // white backward pawns
      if ((board.pieceBoards[1][Piece.PAWN] & WHITE_BACKWARDS_MASK[pawnSquareIndex]) == 0 && pawnSquare.rank > 1)
      {
        whitePawnScore -= PAWN_BACKWARDS_VALUE[pawnSquare.file];
        //if(DEBUG)System.err.println("    Backwards");
        if((board.pieceBoards[0][Piece.PAWN] & FILES[pawnSquare.file]) == 0)
        {
          //if(DEBUG)System.err.println("    Double Backwards");
          whitePawnScore -= PAWN_BACKWARDS_VALUE[pawnSquare.file];
        }
      }

      // doubled pawns
      else if (((board.pieceBoards[1][Piece.PAWN] & BLACK_PASSED_MASK[pawnSquare.index64] & FILES[pawnSquare.file])) != 0)
      {
        whitePawnScore -= PAWN_DOUBLED_VALUE;
        //if(DEBUG)System.err.println("    Doubled Pawn");
      }

      // locked files
      if ((board.pieceBoards[0][Piece.PAWN] & Board.SQUARES[pawnSquare.index64 + 8].mask_on) != 0)
      {
        pawnHashEntry.pawnFlags.lockedFiles |= FILES[pawnSquare.file];
        //if(DEBUG)System.err.println("    Locked File");
//        continue;
      }

      // white passed pawns
      if ((board.pieceBoards[0][Piece.PAWN] & WHITE_PASSED_MASK[pawnSquareIndex]) == 0)
      {
        pawnHashEntry.pawnFlags.whitePassedPawns |= pawnSquare.mask_on;
        //if(DEBUG)System.err.println("    Passed");
      }

      if (pawnSquare.file == 0)
      {
        // white pawn chain (H1-A8)
        if ((board.pieceBoards[1][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 7].mask_on) != 0)
        {
          whitePawnScore += whitePawnValueTable[pawnSquareIndex - 7];
          pawnHashEntry.pawnFlags.closedFiles[0] |= FILES[pawnSquare.file] & BLACK_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    H1-A8 Chain");
        }
      }
      else if (pawnSquare.file == 7)
      {
        // white pawn phalanx
        if ((board.pieceBoards[1][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 1].mask_on) != 0 && pawnSquare.rank > 1)
        {
          whitePawnScore += whitePawnValueTable[pawnSquareIndex - 1];
          //if(DEBUG)System.err.println("    Phalanx");
        }
        // white pawn chain (A1-H8)
        if (((board.pieceBoards[1][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 9].mask_on) != 0))
        {
          whitePawnScore += whitePawnValueTable[pawnSquareIndex - 9];
          pawnHashEntry.pawnFlags.closedFiles[0] |= FILES[pawnSquare.file] & BLACK_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    A1-H8 Chain");
        }
      }
      else
      {
        // white pawn phalanx
        if ((board.pieceBoards[1][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 1].mask_on) != 0 && pawnSquare.rank > 1)
        {
          whitePawnScore += whitePawnValueTable[pawnSquareIndex - 1];
          //if(DEBUG)System.err.println("    Phalanx");
        }
        // white pawn chain (A1-H8)
        if (((board.pieceBoards[1][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 9].mask_on) != 0))
        {
          whitePawnScore += whitePawnValueTable[pawnSquareIndex - 9];
          pawnHashEntry.pawnFlags.closedFiles[0] |= FILES[pawnSquare.file] & BLACK_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    A1-H8 Chain");
        }
        // white pawn chain (H1-A8)
        if (((board.pieceBoards[1][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 7].mask_on) != 0))
        {
          whitePawnScore += whitePawnValueTable[pawnSquareIndex - 7];
          pawnHashEntry.pawnFlags.closedFiles[0] |= FILES[pawnSquare.file] & BLACK_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    H1-A8 Chain");
        }
      }
    }

    int[] blackPawnValueTable = PIECE_VALUE_TABLES[0][Piece.PAWN];
    while (blackPawns != 0)
    {
      int pawnSquareIndex = Board.getLeastSignificantBit(blackPawns);
      blackPawns &= (blackPawns - 1);
      pawnSquare = Board.SQUARES[pawnSquareIndex];

      //if(DEBUG)System.err.println("  p@" + pawnSquare.toString());

      blackPawnScore += Piece.TYPE_VALUES[Piece.PAWN];
      pawnHashEntry.pawnFlags.blackPawnCount++;
      pawnHashEntry.pawnFlags.openFiles &= ~FILES[pawnSquare.file];
      pawnHashEntry.pawnFlags.openRanks &= ~RANKS[pawnSquare.rank];
      blackPawnScore += blackPawnValueTable[pawnSquareIndex];
      pawnHashEntry.pawnFlags.closedFiles[0] |= FILES[pawnSquare.file] & BLACK_HALF[pawnSquare.index64];

      // black backward pawns
      if ((board.pieceBoards[0][Piece.PAWN] & BLACK_BACKWARDS_MASK[pawnSquareIndex]) == 0 && pawnSquare.rank < 6)
      {
        blackPawnScore -= PAWN_BACKWARDS_VALUE[pawnSquare.file];
        //if(DEBUG)System.err.println("    Backwards");
        if((board.pieceBoards[1][Piece.PAWN] & FILES[pawnSquare.file]) == 0)
        {
          blackPawnScore -= PAWN_BACKWARDS_VALUE[pawnSquare.file];
          //if(DEBUG)System.err.println("    Doubled Backwards");
        }
      }

      // doubled pawns
      else if ((board.pieceBoards[0][Piece.PAWN] & WHITE_PASSED_MASK[pawnSquare.index64] & FILES[pawnSquare.file]) != 0)
      {
        blackPawnScore -= PAWN_DOUBLED_VALUE;
        //if(DEBUG)System.err.println("    Doubled Pawn");
      }

      // locked files
      if ((board.pieceBoards[1][Piece.PAWN] & Board.SQUARES[pawnSquare.index64 - 8].mask_on) != 0)
      {
        pawnHashEntry.pawnFlags.closedFiles[0] |= FILES[pawnSquare.file] & BLACK_HALF[pawnSquare.index64];
        //if(DEBUG)System.err.println("    Locked File");
//        continue;
      }

      // black passed pawns
      if ((board.pieceBoards[1][Piece.PAWN] & BLACK_PASSED_MASK[pawnSquareIndex]) == 0)
      {
        pawnHashEntry.pawnFlags.blackPassedPawns |= pawnSquare.mask_on;
        //if(DEBUG)System.err.println("    Passed");
      }

      if (pawnSquare.file == 0)
      {
        // black pawn chain (A1-H8)
        if (((board.pieceBoards[0][Piece.PAWN] & Board.SQUARES[pawnSquareIndex + 9].mask_on) != 0))
        {
          blackPawnScore += blackPawnValueTable[pawnSquareIndex + 9];
          pawnHashEntry.pawnFlags.closedFiles[1] |= FILES[pawnSquare.file] & WHITE_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    A1-H8 Chain");
        }
      }
      else if (pawnSquare.file == 7)
      {
        // black pawn phalanx
        if ((board.pieceBoards[0][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 1].mask_on) != 0 && pawnSquare.rank < 6)
        {
          blackPawnScore += blackPawnValueTable[pawnSquareIndex - 1];
          //if(DEBUG)System.err.println("    Phalanx");
        }
        // black pawn chain (H1-A8)
        if (((board.pieceBoards[0][Piece.PAWN] & Board.SQUARES[pawnSquareIndex + 7].mask_on) != 0))
        {
          blackPawnScore += blackPawnValueTable[pawnSquareIndex + 7];
          pawnHashEntry.pawnFlags.closedFiles[1] |= FILES[pawnSquare.file] & WHITE_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    H1-A8 Chain");
        }
      }
      else
      {
        // black pawn phalanx
        if ((board.pieceBoards[0][Piece.PAWN] & Board.SQUARES[pawnSquareIndex - 1].mask_on) != 0 && pawnSquare.rank < 6)
        {
          blackPawnScore += blackPawnValueTable[pawnSquareIndex - 1];
          //if(DEBUG)System.err.println("    Phalanx");
        }
        // black pawn chain (A1-H8)
        if (((board.pieceBoards[0][Piece.PAWN] & Board.SQUARES[pawnSquareIndex + 9].mask_on) != 0))
        {
          blackPawnScore += blackPawnValueTable[pawnSquareIndex + 9];
          pawnHashEntry.pawnFlags.closedFiles[1] |= FILES[pawnSquare.file] & WHITE_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    A1-H8 Chain");
        }
        // black pawn chain (H1-A8)
        if (((board.pieceBoards[0][Piece.PAWN] & Board.SQUARES[pawnSquareIndex + 7].mask_on) != 0))
        {
          blackPawnScore += blackPawnValueTable[pawnSquareIndex + 7];
          pawnHashEntry.pawnFlags.closedFiles[1] |= FILES[pawnSquare.file] & WHITE_HALF[pawnSquare.index64];
          //if(DEBUG)System.err.println("    H1-A8 Chain");
        }
      }
    }

    score += whitePawnScore - blackPawnScore;

    int whiteQueenside = normalizeQueensidePawns(board, pawnHashEntry.pawnFlags.lockedFiles, 1);
    int blackQueenside = normalizeQueensidePawns(board, pawnHashEntry.pawnFlags.lockedFiles, 0);
    int whiteKingside = normalizeKingsidePawns(board, pawnHashEntry.pawnFlags.lockedFiles, 1);
    int blackKingside = normalizeKingsidePawns(board, pawnHashEntry.pawnFlags.lockedFiles, 0);
    int whiteCenter = normalizeCenterPawns(board, 1);
    int blackCenter = normalizeCenterPawns(board, 0);

    int queensideScore = PAWNSCORES[ (whiteQueenside << 3) + blackQueenside];
    int kingsideScore = PAWNSCORES[ (whiteKingside << 3) + blackKingside];
    int centerScore = PAWNSCORES[ (whiteCenter << 3) + blackCenter];

    pawnHashEntry.pawnFlags.centerScore = centerScore;
    pawnHashEntry.pawnFlags.endgameScore = queensideScore + kingsideScore;

    pawnHashEntry.pawnFlags.score = score;

    // Store pawn hash
    pawnHashEntry.hash = board.pawnHash;

    return pawnHashEntry.pawnFlags;
  }

  private int normalizeQueensidePawns(Board board, long lockedFiles, int color)
  {
    long pawns = board.pieceBoards[color][Piece.PAWN] & ~lockedFiles;
    if((pawns & FILES[0]) != 0)
    {
      if((pawns & FILES[1]) != 0)
      {
        // ABC
        if((pawns & FILES[2]) != 0)
        {
          return 7;
        }
        // AB
        else
        {
          return 6;
        }

      }
      // A C
      else if((pawns & FILES[2]) != 0)
      {
        return 5;
      }
      // A
      else
      {
        return 4;
      }
    }
    else if((pawns & FILES[1]) != 0)
    {
      //  BC
      if((pawns & FILES[2]) != 0)
      {
        return 3;
      }
      //  B
      else
      {
        return 2;
      }
    }
    //   C
    else if((pawns & FILES[2]) != 0)
    {
      return 1;
    }
    return 0;
  }

  private int normalizeKingsidePawns(Board board, long lockedFiles, int color)
  {
    long pawns = board.pieceBoards[color][Piece.PAWN] & ~lockedFiles;
    if((pawns & FILES[7]) != 0)
    {
      if((pawns & FILES[6]) != 0)
      {
        // HGF
        if((pawns & FILES[5]) != 0)
        {
          return 7;
        }
        // HG
        else
        {
          return 6;
        }

      }
      // H F
      else if((pawns & FILES[5]) != 0)
      {
        return 5;
      }
      // H
      else
      {
        return 4;
      }
    }
    else if((pawns & FILES[6]) != 0)
    {
      //  GF
      if((pawns & FILES[5]) != 0)
      {
        return 3;
      }
      //  G
      else
      {
        return 2;
      }
    }
    //   F
    else if((pawns & FILES[5]) != 0)
    {
      return 1;
    }
    return 0;
  }

  private int normalizeCenterPawns(Board board, int color)
  {
    long pawns = board.pieceBoards[color][Piece.PAWN];
    if((pawns & FILES[3]) != 0)
    {
      // ED
      if((pawns & FILES[4]) != 0)
      {
        return 3;
      }
      // E
      else
      {
        return 2;
      }

    }
    // D
    else if((pawns & FILES[4]) != 0)
    {
      return 1;
    }
    return 0;
  }

  private int scorePassedPawns(Board board,
                               long whitePassedPawns,
                               long blackPassedPawns,
                               int whiteMaterial,
                               int blackMaterial)
  {
    int score = 0;

/*
    if(whiteMaterial > 21 || blackMaterial > 21)
    {
      return 0;
    }
*/
    double whiteMaterialRatio = 1 - (whiteMaterial / 38D);
    double blackMaterialRatio = 1 - (blackMaterial / 38D);

    int whiteScore = 0;
    int blackScore = 0;

    while (whitePassedPawns != 0)
    {
      int pawnSquareIndex = Board.getLeastSignificantBit(whitePassedPawns);
      whitePassedPawns &= (whitePassedPawns - 1);

      if (Board.SQUARES[pawnSquareIndex].file < 2 && Board.SQUARES[pawnSquareIndex].file < board.blackKing.square.file - 2)
      {
        whiteScore += PASSED_PAWN_WIDE_FILE_VALUE * blackMaterialRatio;
      }
      else if (Board.SQUARES[pawnSquareIndex].file > 5 && Board.SQUARES[pawnSquareIndex].file > board.blackKing.square.file + 2)
      {
        whiteScore += PASSED_PAWN_WIDE_FILE_VALUE * blackMaterialRatio;
      }

      Square advancingSquare = Board.SQUARES[pawnSquareIndex + 8];

      if ((board.allPieces & advancingSquare.mask_on) == 0)
      {
        whiteScore += (WHITE_PASSED_PAWN_VALUES[(board.turn == 1 ? advancingSquare.index64 : pawnSquareIndex)  >> 3]);

        Square queeningSquare = Board.SQUARES[((pawnSquareIndex & 7) + 56)];
        long bishopAttacks = board.bishopAttacks(queeningSquare.index64);
        long rookAttacks = board.rookAttacks(queeningSquare.index64);
        int attackers = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, queeningSquare, 1, true);
        int defenders = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, queeningSquare, 0, true);

        if (attackers - defenders >= 0 || defenders == 0)
        {
          whiteScore += (WHITE_PASSED_PAWN_VALUES[(board.turn == 1 ? advancingSquare.index64 : pawnSquareIndex) >> 3] >> 1);
        }
      }
      else
      {
        whiteScore += (WHITE_PASSED_PAWN_VALUES[pawnSquareIndex >> 3]);
      }
    }

    while (blackPassedPawns != 0)
    {
      int pawnSquareIndex = Board.getLeastSignificantBit(blackPassedPawns);
      blackPassedPawns &= (blackPassedPawns - 1);

      if (Board.SQUARES[pawnSquareIndex].file < 2 && Board.SQUARES[pawnSquareIndex].file < board.whiteKing.square.file - 2)
      {
        blackScore += PASSED_PAWN_WIDE_FILE_VALUE * whiteMaterialRatio;
      }
      else if (Board.SQUARES[pawnSquareIndex].file > 5 && Board.SQUARES[pawnSquareIndex].file > board.whiteKing.square.file + 2)
      {
        blackScore += PASSED_PAWN_WIDE_FILE_VALUE * whiteMaterialRatio;
      }

      Square advancingSquare = Board.SQUARES[pawnSquareIndex - 8];

      if ((board.allPieces & advancingSquare.mask_on) == 0)
      {
        blackScore += (BLACK_PASSED_PAWN_VALUES[(board.turn == 0 ? advancingSquare.index64 : pawnSquareIndex) >> 3]);

        Square queeningSquare = Board.SQUARES[(pawnSquareIndex & 7)];
        long bishopAttacks = board.bishopAttacks(queeningSquare.index64);
        long rookAttacks = board.rookAttacks(queeningSquare.index64);
        int attackers = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, queeningSquare, 0, true);
        int defenders = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, queeningSquare, 1, true);

        if (attackers - defenders >= 0 || defenders == 0)
        {
          blackScore += (BLACK_PASSED_PAWN_VALUES[(board.turn == 0 ? advancingSquare.index64 : pawnSquareIndex) >> 3] >> 1);
        }
      }
      else
      {
        blackScore += (BLACK_PASSED_PAWN_VALUES[pawnSquareIndex >> 3]);
      }
    }

    whiteScore *= blackMaterialRatio;
    blackScore *= whiteMaterialRatio;

    return whiteScore - blackScore;
  }

  //////////////////
  // EVAL WHITE KING
  //////////////////

  private int evalWhiteKing(Board board, PawnFlags pawnFlags)
  {
    Square kingSquare = board.whiteKing.square;
    int score = 0;

    if ((board.pieceBoards[0][Piece.QUEEN] == 0))
    {
      score += PIECE_VALUE_TABLES[0][Piece.KNIGHT][kingSquare.index64];
      int nearbyPassedPawns = Board.countBits(
              (mask3 << (kingSquare.file > 0 ?
                         kingSquare.index64 + 7 :
                         kingSquare.index64 + 8)) &
                                                  (pawnFlags.whitePassedPawns)
      );
      score += nearbyPassedPawns * kingSquare.rank * 7;
      return score;
    }

    int attackers = 0;

    attackers = scoreAttackingPieces(board,
                                     kingSquare,
                                     0);
    if (board.stats.whiteCastleFlag == 0 && board.whiteKing.moveCount > 0 && (board.whiteKing.square.file < 6 && board.whiteKing.square.file > 2))
    {
      score -= KING_FORFEIT_CASTLE_VALUE;
    }
    score -= attackers;

    return score;
  }

  //////////////////
  // EVAL BLACK KING
  //////////////////

  private int evalBlackKing(Board board, PawnFlags pawnFlags)
  {
    Square kingSquare = board.blackKing.square;
    int score = 0;

    if ((board.pieceBoards[1][Piece.QUEEN] == 0))
    {
      score += PIECE_VALUE_TABLES[0][Piece.KNIGHT][kingSquare.index64];
      int nearbyPassedPawns = Board.countBits(
              (mask3 << (kingSquare.file > 0 ?
                         kingSquare.index64 - 9 :
                         kingSquare.index64 - 8)) &
                                                  (pawnFlags.blackPassedPawns)
      );
      score += nearbyPassedPawns * (7 - kingSquare.rank) * 7;
      return score;
    }

    int attackers = 0;

    attackers = scoreAttackingPieces(board,
                                     kingSquare,
                                     1);
    if (board.stats.blackCastleFlag == 0 && board.blackKing.moveCount > 0 && (board.blackKing.square.file < 6 && board.blackKing.square.file > 2))
    {
      score -= KING_FORFEIT_CASTLE_VALUE;
    }
    score -= attackers;

    return score;
  }

  private static int[][] KING_SAFETY_STAGING_AREA = new int[2][3];
  private static int[][] KING_SAFETY_PAWN_AREA = new int[2][3];
  private static int[][] KING_SAFETY_TINY_AREA = new int[2][5];

  static
  {
    KING_SAFETY_STAGING_AREA[1] = new int[]{31, 32, 33};
    KING_SAFETY_STAGING_AREA[0] = new int[]{-31, -32, -33};

    KING_SAFETY_PAWN_AREA[1] = new int[]{15, 16, 17};
    KING_SAFETY_PAWN_AREA[0] = new int[]{-15, -16, -17};

    KING_SAFETY_TINY_AREA[1] = new int[]{1, -1, -15, -16, -17};
    KING_SAFETY_TINY_AREA[0] = new int[]{1, -1, 15, 16, 17};

  }

  /**
   * count
   * [1 - 3] [ P ] [ minor ] [ R ] [ Q ] [ K ]
   *
   * @param board
   * @param kingSquare
   * @param color
   * @return
   */
  private int scoreAttackingPieces(Board board,
                                   Square kingSquare,
                                   int color)
  {
    int score = 0;
    int pawnScore = 0;
    int tinyScore = 0;
    int stagingScore = 0;
    int enemyColor = color ^ 1;
    int vulnerability = 4;
    Square square;
    long bishopAttacks;
    long rookAttacks;
    Board.BoardSquare boardSquare;
    int attackingScore;
    int defenderScore;
    int squareIndex;

    for (int i = 0; i < 3; i++)
    {
      squareIndex = kingSquare.index128 + KING_SAFETY_STAGING_AREA[enemyColor][i];
      if ((squareIndex & 0x88) != 0)
      {
        continue;
      }

      square = board.boardSquares[squareIndex].square;

      bishopAttacks = board.bishopAttacks(square.index64);
      rookAttacks = board.rookAttacks(square.index64);
      attackingScore = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, square, color, true);
      if (attackingScore > 0)
      {
        defenderScore = scoreDefenseOfSquare(board, bishopAttacks, rookAttacks, square, enemyColor, true);
        stagingScore += (attackingScore - defenderScore) >> 1;
      }

      squareIndex = kingSquare.index128 + KING_SAFETY_PAWN_AREA[enemyColor][i];
      boardSquare = board.boardSquares[squareIndex];
      square = boardSquare.square;

      if(boardSquare.piece != null && (boardSquare.piece.type == Piece.PAWN || boardSquare.piece.type == Piece.BISHOP) && boardSquare.piece.color != color)
      {
        vulnerability--;
      }

      bishopAttacks = board.bishopAttacks(square.index64);
      rookAttacks = board.rookAttacks(square.index64);
      attackingScore = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, square, color, true);
      if (attackingScore > 0)
      {
        defenderScore = scoreDefenseOfSquare(board, bishopAttacks, rookAttacks, square, enemyColor, true);
        pawnScore += (attackingScore - defenderScore);
      }
    }

    for (int i = 0; i < 5; i++)
    {
      squareIndex = kingSquare.index128 + KING_SAFETY_TINY_AREA[enemyColor][i];
      if ((squareIndex & 0x88) != 0)
      {
        continue;
      }
      square = board.boardSquares[squareIndex].square;

      bishopAttacks = board.bishopAttacks(square.index64);
      rookAttacks = board.rookAttacks(square.index64);
      attackingScore = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, square, color, true);
      if (attackingScore > 0)
      {
        defenderScore = scoreDefenseOfSquare(board, bishopAttacks, rookAttacks, square, enemyColor, false);
        tinyScore += attackingScore - defenderScore;
      }
    }

/*
    if(DEBUG) System.err.println((color == 0 ? "White" : "Black") + " King Safety");
    if(DEBUG) System.err.println("  Staging Score: " + stagingScore);
    if(DEBUG) System.err.println("  Pawn Score: " + pawnScore);
    if(DEBUG) System.err.println("  Tiny Score: " + tinyScore);
    if(DEBUG) System.err.println("  Vulnerability: " + vulnerability);
*/
    score = tinyScore + (((stagingScore) * vulnerability)) + pawnScore;
    return max(score, 0);

  }

  private int scoreStagingSquare(Board board, int color, int enemyColor, int squareIndex)
  {
    if ((squareIndex & 0x88) != 0)
    {
      return 0;
    }

    Square square = board.boardSquares[squareIndex].square;
    long bishopAttacks = board.bishopAttacks(square.index64);
    long rookAttacks = board.rookAttacks(square.index64);

    int attackingScore = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, square, color, true);
    int defenderScore = scoreDefenseOfSquare(board, bishopAttacks, rookAttacks, square, enemyColor, false) >> 2;

    return attackingScore - defenderScore;
  }

  private int scorePawnSquare(Board board, int color, int enemyColor, int squareIndex)
  {
    if ((squareIndex & 0x88) != 0)
    {
      return 0;
    }

    Square square = board.boardSquares[squareIndex].square;
    long bishopAttacks = board.bishopAttacks(square.index64);
    long rookAttacks = board.rookAttacks(square.index64);

    int attackingScore = scoreAttacksToSquare(board, bishopAttacks, rookAttacks, square, color, false);
    int defenderScore = scoreDefenseOfSquare(board, bishopAttacks, rookAttacks, square, enemyColor, true) >> 2;
    return attackingScore - defenderScore;
  }

  private int scoreTinySquare(Board board, int color, int squareIndex)
  {
    if ((squareIndex & 0x88) != 0)
    {
      return 0;
    }
    Square square = board.boardSquares[squareIndex].square;
    long bishopAttacks = board.bishopAttacks(square.index64);
    long rookAttacks = board.rookAttacks(square.index64);
    return scoreAttacksToSquare(board, bishopAttacks, rookAttacks, square, color, false);
  }

  public int scoreAttacksToSquare(Board board, long bishopAttacks, long rookAttacks, Square square, int color, boolean rewardOccupancy)
  {
    int score = 0;

    int pawns = 0;
    int minors = 0;
    int rooks = 0;
    int queens = 0;
    int king = 0;

    long pawnAttackers = (MoveGeneration.attackVectors[color][Piece.PAWN][square.index64] & board.pieceBoards[color][Piece.PAWN]);
    if (pawnAttackers != 0)
    {
      if ((pawnAttackers & (pawnAttackers - 1)) != 0)
      {
        pawns++;
      }
      pawns++;
    }
    long knightAttackers = (MoveGeneration.attackVectors[color][Piece.KNIGHT][square.index64] & board.pieceBoards[color][Piece.KNIGHT]);
    if (knightAttackers != 0)
    {
      if ((knightAttackers & (knightAttackers - 1)) != 0)
      {
        minors++;
      }
      minors++;
    }
    if ((bishopAttacks & board.pieceBoards[color][Piece.BISHOP]) != 0)
    {
      minors++;
    }
    long rookAttackers = rookAttacks & board.pieceBoards[color][Piece.ROOK];
    if ((rookAttacks & board.pieceBoards[color][Piece.ROOK]) != 0)
    {
      if ((rookAttackers & (rookAttackers - 1)) != 0)
      {
        rooks++;
      }
      rooks++;
    }
    if (((bishopAttacks | rookAttacks) & board.pieceBoards[color][Piece.QUEEN]) != 0)
    {
      queens++;
    }
    long kingAttackers = (MoveGeneration.attackVectors[color][Piece.KING][square.index64] & board.pieceBoards[color][Piece.KING]);
    if (kingAttackers != 0)
    {
      king++;
    }

    int pawnValue = 0;
    int minorValue = 0;
    int rookValue = 0;
    int queenValue = 0;

    Piece pieceOnSquare = board.boardSquares[square.index128].piece;
    if (rewardOccupancy && pieceOnSquare != null && pieceOnSquare.color == color)
    {
      switch (pieceOnSquare.type)
      {
        case Piece.PAWN:
        {
          pawns++;
          break;
        }
        case Piece.KNIGHT:
        {
          minors++;
          break;
        }
        case Piece.BISHOP:
        {
          minors++;
          break;
        }
        case Piece.ROOK:
        {
          rooks++;
          break;
        }
        case Piece.QUEEN:
        {
          queens++;
          break;
        }
        case Piece.KING:
        {
          king++;
          break;
        }
      }
    }

    if (pawns > 0)
    {
      minorValue += pawns * 5;
      rookValue += pawns * 5;
      queenValue += pawns * 45;
      pawnValue +=  pawns * 5;
    }
    if (minors > 0)
    {
      pawnValue +=  minors * 5;
      rookValue += minors * 20;
      queenValue += minors * 45;
      minorValue += minors * 20;
    }
    if (rooks > 0)
    {
      pawnValue +=  rooks * 5;
      minorValue += rooks * 20;
      rookValue += rooks * 20;
      queenValue += rooks * 45;
    }

    if (queens > 0)
    {
      pawnValue +=  queens * 5;
      minorValue += queens * 20;
      rookValue += queens * 25;
      queenValue += queens * 15;
    }

    score = (pawns * pawnValue) + (minors * minorValue) + (rooks * rookValue) + (queens * queenValue) + king;

    return score;
  }

  public int scoreDefenseOfSquare(Board board, long bishopAttacks, long rookAttacks, Square square, int color, boolean rewardOccupancy)
  {
    int score = 0;
    int pawns = 0;
    int minors = 0;
    int rooks = 0;
    int queens = 0;


    long pawnAttackers = (MoveGeneration.attackVectors[color][Piece.PAWN][square.index64] & board.pieceBoards[color][Piece.PAWN]);
    if (pawnAttackers != 0)
    {
      if ((pawnAttackers & (pawnAttackers - 1)) != 0)
      {
        pawns++;
      }
      pawns++;
    }
    long knightAttackers = (MoveGeneration.attackVectors[color][Piece.KNIGHT][square.index64] & board.pieceBoards[color][Piece.KNIGHT]);
    if (knightAttackers != 0)
    {
      if ((knightAttackers & (knightAttackers - 1)) != 0)
      {
        minors++;
      }
      minors++;
    }
    if ((bishopAttacks & board.pieceBoards[color][Piece.BISHOP]) != 0)
    {
      minors++;
    }
    long rookAttackers = rookAttacks & board.pieceBoards[color][Piece.ROOK];
    if ((rookAttacks & board.pieceBoards[color][Piece.ROOK]) != 0)
    {
      if ((rookAttackers & (rookAttackers - 1)) != 0)
      {
        rooks++;
      }
      rooks++;
    }
    if (((bishopAttacks | rookAttacks) & board.pieceBoards[color][Piece.QUEEN]) != 0)
    {
      queens++;
    }

    int pawnValue = 0;
    int minorValue = 0;
    int rookValue = 0;
    int queenValue = 0;

    Piece pieceOnSquare = board.boardSquares[square.index128].piece;

    if (rewardOccupancy && pieceOnSquare != null && pieceOnSquare.color == color)
    {
      switch (pieceOnSquare.type)
      {
        case Piece.PAWN:
        {
          pawns++;
          break;
        }
        case Piece.KNIGHT:
        {
          minors++;
          break;
        }
        case Piece.BISHOP:
        {
          minors++;
          break;
        }
        case Piece.ROOK:
        {
          rooks++;
          break;
        }
        case Piece.QUEEN:
        {
          queens++;
          break;
        }
      }
    }

    if (pawns > 0)
    {
      pawnValue += 30;
      minorValue += 10;
      rookValue +=  5;
      queenValue +=  5;
    }
    if (minors > 0)
    {
      pawnValue += 20;
      minorValue += 15;
      rookValue +=  5;
      queenValue +=  5;
    }
    if (rooks > 0)
    {
      pawnValue +=  5;
      minorValue +=  5;
      rookValue +=  5;
      queenValue += 2;
    }

    if (queens > 0)
    {
      pawnValue += 10;
      minorValue +=  5;
      rookValue +=  5;
      queenValue += 2;
    }

    score = (pawns * pawnValue) + (minors * minorValue) + (rooks * rookValue) + (queens * queenValue);

    return score;
  }

  private int countDefendingPieces(Board board, long kingArea, int color)
  {
    int attackers = Board.countBits(kingArea & (board.pieceBoards[color][Piece.KNIGHT] |
                                                board.pieceBoards[color][Piece.BISHOP] |
                                                board.pieceBoards[color][Piece.QUEEN] |
                                                board.pieceBoards[color][Piece.ROOK]));
    return attackers;
  }

  private static long getSmallKingArea(Square square)
  {
    return (square.file < 7 ?
            MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 + 1] :
            0)
           | (square.rank > 1 && square.file < 7 ?
              MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 - 7] :
              0)
           | (square.rank > 1 ?
              MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 - 8] :
              0)
           | (square.rank > 1 && square.file > 0 ?
              MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 - 9] :
              0)
           | (square.file > 0 ?
              MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 - 1] :
              0)
           | (square.rank < 7 && square.file > 0 ?
              MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 + 7] :
              0)
           | (square.rank < 7 ?
              MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 + 8] :
              0)
           | (square.rank < 7 && square.file < 7 ?
              MoveGeneration.attackVectors[0][Piece.KNIGHT][square.index64 + 9] :
              0);
  }

  private static long getKingAreaA1H8(Square square)
  {
    return MoveGeneration.attackVectors[0][7][square.index64]
           | (square.file > 0 ?
              MoveGeneration.attackVectors[0][7][square.index64 - 1] :
              0)
           | (square.file < 7 ?
              MoveGeneration.attackVectors[0][7][square.index64 + 1] :
              0)
           | (square.rank > 0 ?
              MoveGeneration.attackVectors[0][7][square.index64 - 8] :
              0)
           | (square.rank < 7 ?
              MoveGeneration.attackVectors[0][7][square.index64 + 8] :
              0)
           | (square.rank < 7 && square.file > 0 ?
              MoveGeneration.attackVectors[0][7][square.index64 + 7] :
              0)
           | (square.rank < 7 && square.file < 7 ?
              MoveGeneration.attackVectors[0][7][square.index64 + 9] :
              0)
           | (square.rank > 0 && square.file > 0 ?
              MoveGeneration.attackVectors[0][7][square.index64 - 9] :
              0)
           | (square.rank > 0 && square.file < 7 ?
              MoveGeneration.attackVectors[0][7][square.index64 - 7] :
              0);
  }

  private static long getKingAreaH1A8(Square square)
  {
    return MoveGeneration.attackVectors[0][8][square.index64]
           | (square.file > 0 ?
              MoveGeneration.attackVectors[0][8][square.index64 - 1] :
              0)
           | (square.file < 7 ?
              MoveGeneration.attackVectors[0][8][square.index64 + 1] :
              0)
           | (square.rank > 0 ?
              MoveGeneration.attackVectors[0][8][square.index64 - 8] :
              0)
           | (square.rank < 7 ?
              MoveGeneration.attackVectors[0][8][square.index64 + 8] :
              0)
           | (square.rank < 7 && square.file > 0 ?
              MoveGeneration.attackVectors[0][8][square.index64 + 7] :
              0)
           | (square.rank < 7 && square.file < 7 ?
              MoveGeneration.attackVectors[0][8][square.index64 + 9] :
              0)
           | (square.rank > 0 && square.file > 0 ?
              MoveGeneration.attackVectors[0][8][square.index64 - 9] :
              0)
           | (square.rank > 0 && square.file < 7 ?
              MoveGeneration.attackVectors[0][8][square.index64 - 7] :
              0);
  }

  private int max(int a, int b)
  {
    return a > b ?
           a :
           b;
  }

  private int min(int a, int b)
  {
    return a < b ?
           a :
           b;
  }

  private double max(double a, double b)
  {
    return a > b ?
           a :
           b;
  }

  private double min(double a, double b)
  {
    return a > b ?
           a :
           b;
  }

  public static void multiplyAll(int[] original, int factor)
  {
    for (int i = 0; i < original.length; i++)
    {
      original[i] *= factor;
    }
  }

  public int getMaterial(Board board)
  {
    int whiteKnightCount = Board.countBits(board.pieceBoards[1][Piece.KNIGHT]);
    int blackKnightCount = Board.countBits(board.pieceBoards[0][Piece.KNIGHT]);

    int whiteBishopCount = Board.countBits(board.pieceBoards[1][Piece.BISHOP]);
    int blackBishopCount = Board.countBits(board.pieceBoards[0][Piece.BISHOP]);

    int whiteRookCount = Board.countBits(board.pieceBoards[1][Piece.ROOK]);
    int blackRookCount = Board.countBits(board.pieceBoards[0][Piece.ROOK]);

    int whiteQueenCount = Board.countBits(board.pieceBoards[1][Piece.QUEEN]);
    int blackQueenCount = Board.countBits(board.pieceBoards[0][Piece.QUEEN]);

    int whiteMaterial = (whiteKnightCount * 3) + (whiteBishopCount * 3) + (whiteRookCount * 5) + (whiteQueenCount * 9);
    int blackMaterial = (blackKnightCount * 3) + (blackBishopCount * 3) + (blackRookCount * 5) + (blackQueenCount * 9);

    return whiteMaterial + blackMaterial;
  }

  public int getMaterialDifference(Board board)
  {
    int whiteKnightCount = Board.countBits(board.pieceBoards[1][Piece.KNIGHT]);
    int blackKnightCount = Board.countBits(board.pieceBoards[0][Piece.KNIGHT]);

    int whiteBishopCount = Board.countBits(board.pieceBoards[1][Piece.BISHOP]);
    int blackBishopCount = Board.countBits(board.pieceBoards[0][Piece.BISHOP]);

    int whiteRookCount = Board.countBits(board.pieceBoards[1][Piece.ROOK]);
    int blackRookCount = Board.countBits(board.pieceBoards[0][Piece.ROOK]);

    int whiteQueenCount = Board.countBits(board.pieceBoards[1][Piece.QUEEN]);
    int blackQueenCount = Board.countBits(board.pieceBoards[0][Piece.QUEEN]);

    int whiteMaterial = (whiteKnightCount * 3) + (whiteBishopCount * 3) + (whiteRookCount * 5) + (whiteQueenCount * 9);
    int blackMaterial = (blackKnightCount * 3) + (blackBishopCount * 3) + (blackRookCount * 5) + (blackQueenCount * 9);

    return whiteMaterial - blackMaterial;
  }


  public int getBlackKingSafety(Board board)
  {
    PawnFlags pawnFlags = scorePawns(board);

    return evalBlackKing(board, pawnFlags);
  }

  public int getWhiteKingSafety(Board board)
  {
    PawnFlags pawnFlags = scorePawns(board);

    return evalWhiteKing(board, pawnFlags);
  }


  public int getKingSafety(Board board)
  {
    return getWhiteKingSafety(board) - getBlackKingSafety(board);
  }

  public int getPawns(Board board)
  {
    int whitePawnCount = Board.countBits(board.pieceBoards[1][Piece.KNIGHT]);
    int blackPawnCount = Board.countBits(board.pieceBoards[0][Piece.KNIGHT]);

    return whitePawnCount + blackPawnCount;
  }

  public int getPawnsDifference(Board board)
  {
    int whitePawnCount = Board.countBits(board.pieceBoards[1][Piece.KNIGHT]);
    int blackPawnCount = Board.countBits(board.pieceBoards[0][Piece.KNIGHT]);

    return whitePawnCount - blackPawnCount;
  }


}