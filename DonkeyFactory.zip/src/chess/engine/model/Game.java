/* $Id$ */

package chess.engine.model;

/**
 * @author Joshua Levine <jlevine@theladders.com>
 * @version $Revision$ $Name$ $Date$
 */
public class Game
{
}
