/cygdrive/c/Progra~1/Java/jdk1.6.0_07/bin/java -cp './DonkeyFactory.jar;twitter4j/twitter4j-2.0.8.jar' -Xms64m -Xmx1024m free.chessclub.bot.Bot freechess.org 5000 testdonkeyfactory '' tarabas 
